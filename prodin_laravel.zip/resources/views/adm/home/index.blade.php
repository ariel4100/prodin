@extends('adm.layouts.app')

@section('content')
<div class="container" id="container-fluid">
    <div class="row">
        <div class="col s12"> HOME</div>
    </div>
</div>
@endsection
