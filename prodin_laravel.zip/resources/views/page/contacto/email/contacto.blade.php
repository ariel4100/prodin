
Has recibido un mensaje de : {{ $nombre }}

<p>
Nombre: {{ $nombre }}
</p>

<p>
Apellido: {{ $apellido }}
</p>

<p>
Email: {{ $email }}
</p>




<p>
Empresa: {{ $empresa }}
</p>

<p>
Mensaje: {{ $mensaje }}
</p>