
Has recibido un mensaje de : {{ $nombre }}

<p>
Nombre: {{ $nombre }}
</p>

<p>
Apellido: {{ $localidad }}
</p>

<p>
Email: {{ $email }}
</p>




<p>
Empresa: {{ $telefono }}
</p>

<p>
Mensaje: {{ $mensaje }}
</p>