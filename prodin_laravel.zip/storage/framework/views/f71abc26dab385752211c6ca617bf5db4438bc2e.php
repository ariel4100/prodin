<?php $__env->startSection('style'); ?>
    <style>
        .ion-active{
            width: 200px;
            height: 200px;
            background-color: #094984;
            border-radius: 50%;
            border: 2px solid #094984;

        }


    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="carousel carousel-slider  ">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item   white-text" href="#one!" style="background-image: url(<?php echo e(asset('images/sliders/'.$s->file_image)); ?>)">
                <?php if($s->titulo): ?>
                    <div class="left" style="padding: 0px 50px 10px 50px; background-color: #2DC5EE; margin-top: 100px;" >
                        <?php echo $s->titulo; ?>

                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row " style="background-color: #094984; padding:  3rem; font-family: 'Open Sans'">
        <div class="col s6 offset-s3 center" style="color: white">
            <?php if($informacion): ?>
                <h6><?php echo e($informacion->titulo1); ?></h6>
            <?php endif; ?>
        </div>
    </div>
    <?php if($destacados2): ?>
        <div class="container">
            <h4 class="center" style="color: #2CC5ED; margin-bottom: 3rem; margin-top: 3rem">CATEGORIAS DESTACADAS</h4>
            <div class="row">
                <?php $__currentLoopData = $destacados2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col s3 center">
                            <a href="<?php echo e(route('listar.page', $f->categoria->id)); ?>">
                                <div class="">
                                    <img src= "<?php echo e(asset('images/categoria/'. $f->categoria->file_image)); ?>" class="responsive-img"   alt="smaple image">
                                </div>
                                <p class=" center" style="color: #2CC5ED;"><?php echo e($f->categoria->nombre); ?></p>
                            </a>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
    <?php if($destacados): ?>
        <div class="container">
            <h4 class="center" style="color: #2CC5ED; margin-bottom: 3rem; margin-top: 3rem">PRODUCTOS DESTACADAS</h4>
            <div class="row">
                <?php $__currentLoopData = $destacados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col s3 center">
                            <a href="<?php echo e(route('show.page', $f->producto->id)); ?>">
                            <div class="">
                                <img src= "<?php echo e(asset('images/productos/'. $f->producto->file_image)); ?>" class="responsive-img"   alt="smaple image">
                            </div>
                            <p class=" center" style="color: #2CC5ED;"><?php echo e($f->producto->nombre); ?></p>
                            </a>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
    <div class="row center" style="background-color: #D6D6D6; height: 100%; font-family: 'Open Sans'; padding: 3rem">
        <div class="col s6 offset-s3">
            <h5 style="color: #2CC5ED">CONOZCA LO QUE TENEMOS PARA OFRECERLE</h5>
            <div class="row">
                <form  method="get"  class="col s12" action="<?php echo e(action('SeccionHomeController@buscador')); ?>">
                    <div class="input-field">
                        <i class="material-icons prefix">search</i>
                        <input placeholder="Buscar producto..." id="first_name" type="text" name="nombre" class="validate">
                    </div>
                </form>
            </div>
            <?php $__currentLoopData = $enlaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col s6 center " style="margin-top: 3rem">
                    <img src="<?php echo e(asset('images/enlace/'.$e->file_image)); ?>" class="responsive-img ion-active" alt="">
                    <h6 class="center" style="color: #2CC5ED"><?php echo e($e->nombre); ?></h6>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div style="   padding: 50px 0px">
        <div class="container hide-on-med-and-down ">
            <div class="slick-marcas">
                <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e(asset('images/marcas/'.$m->file_image)); ?>" class="img-responsive" style="height: auto !important; width: auto !important; padding-right: 60px">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $('#slider-home').slider({
                height: 479,
            })
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>