<?php $__env->startSection('content'); ?>
<div class="container" id="container-fluid">
    <div class="row">
        <div class="col s12">
            <nav>
                <div class="nav-wrapper grey">
                    <div class="col s12">
                        <a href="#!" class="breadcrumb">Home</a>
                        <a href="#!" class="breadcrumb">Productos Destacados</a>
                    </div>
                </div>
            </nav>
            <h5>Productos Destacados</h5>
            <div class="divider"></div>
            <table class="index-table-logos responsive-table ">
                <thead>
                <tr>
                    <th>Imagen</th>
                    <th>Nombre</th>
                    <th>Orden</th>
                    <th>Opciones</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $destacados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="width: 200px;"><img src="<?php echo e(asset('images/productos/'.$d->producto->file_image)); ?>"></td>
                        <td style="width: 100px;"><?php echo e($d->producto->nombre); ?></td>
                        <td><?php echo e($d->orden); ?></td>
                        <td>
                            <a href=" <?php echo e(action('ProductoDestacadoController@edit', $d->id)); ?> " class="btn-floating btn-large waves-effect waves-light orange"><i class="material-icons">autorenew</i></a>
                            <a href=" <?php echo e(action('ProductoDestacadoController@create')); ?> " class="btn-floating btn-large waves-effect waves-light orange"><i class="material-icons">add</i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3">No existen registros</td>
                        <td>
                            <a href=" <?php echo e(action('ProductoDestacadoController@create')); ?> " class="btn-floating btn-large waves-effect waves-light orange"><i class="material-icons">add</i></a>
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>