<?php $__env->startSection('style'); ?>
	<style>
		.collapsible {
			border: none;
			box-shadow: none;
		}

		.collapsible-body {
			padding: 0px !important;
		}
		a{
			color: #747484;
		}
		h1,h2,h3,h4,h5,h6{
			font-family: quicksand;
		}


		.slider .slides {
			background-color: #ffffff;
			height: 400px;
		}
		.slider .slides li .caption {
			background-color: rgba(0, 0, 0, 0.6);
			top: 26%;
			padding: 10px 50px;
		}
		.slider .indicators {
			bottom: 5%;
			z-index: 99999;
		}
		.slider .indicators .indicator-item {
			height: 10px;
			width: 10px;
			background-color: rgba(255,255,255,0.7);
		}
		.slider .indicators .indicator-item.active {
			background-color: rgba(255,255,255,1);
		}

		.slider-product-container {
			border: 1px solid #CCCCCC;

		}

		.slider-product, .slider-product .slides {
			height: 350px !important;
		}
		.slider-product .indicators .indicator-item {
			height: 10px;
			width: 10px;
			background-color: rgba(181,181,181,0.7);
		}
		.slider-product .indicators .indicator-item.active {
			background-color: rgba(181,181,181,1);
		}
		strong {
			font-weight: 1000;
		}
	</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" >
		<div class="row">
			<div class="breadcrumb-productos" style="padding: 3%">
				  <a href="<?php echo e(route('listar.page', $producto->categoria_id)); ?>"><?php echo e($producto->categoria->nombre); ?></a> | <a href="<?php echo e(route('show.page', $producto->id)); ?>"><?php echo e($producto->nombre); ?></a>
			</div>
			<div class="col l3 m12 s12">
				<ul class="collapsible" style="font-family: quicksand">
					<?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li <?php if($f->id == $producto->categoria_id): ?> class="active"  style="color: #2DC5EE;" <?php endif; ?>>
							<div class="collapsible-header"
								 style="display:flex; justify-content:space-between; align-items:center; padding:8px">
								<a href="<?php echo e(route('listar.page', $f->id)); ?>" <?php if($f->id == $producto->categoria_id): ?> style="color: #2DC5EE;" <?php endif; ?> class="graysillo">
									<?php echo e($f->nombre); ?>

								</a>
								<i class="material-icons">keyboard_arrow_right</i>
							</div>
							<div class="collapsible-body" style="font-size: 16px !important;" >
								<?php $__currentLoopData = $f->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<ul class="collapsible"  style="font-family: quicksand">
										<li class="active">
											<div class="collapsible-header" style="     padding: unset;   border-bottom: unset;">
												<a href="<?php echo e(route('show.page', $p->id)); ?>" class="graysillo"
												   <?php if(isset($producto)): ?> <?php if($p->id == $producto->id): ?> style="color: #2DC5EE; font-size: 16px !important;" <?php endif; ?> <?php endif; ?>
												><?php echo e($p->nombre); ?></a>
											</div>
										</li>
									</ul>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<div class="col l9 m12 s12">
				<div class="row">
					<div class="col l6 m12 s12">
						<div class="slider-product-container">
							<div class="slider slider-product" style="height: 350px!important;">
								<ul class="slides" style="height: 400px!important;">
									<li>
										<img src="<?php echo e(asset('images/productos/'.$producto->file_image)); ?>">
									</li>
									<?php if($producto->galerias->count() > 0): ?>
										<?php $__currentLoopData = $producto->galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li>
												<img src="<?php echo e(asset('images/productos/galeria/'.$s->file_image)); ?>">
											</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</ul>
							</div>
						</div>
					</div>
					<div class="col l6 m12 s12">
						<h5 style="margin: 0px; color: #2DC5EE; font-family: quicksand; font-size: 25px;"><?php echo e($producto->nombre); ?></h5>
						<p>
							<?php echo $producto->descripcion; ?>

						</p>

						<?php if($producto->file_ficha != null): ?>
							<div class="col s12 m6" >
								<a href="<?php echo e(route('producto-down', $producto->file_ficha)); ?>" target="_blank"  class="waves-effect waves-light btn z-depth-0" id="estandar-btn" style="background: #094984 !important; border-radius: 0 !important">FICHA TECNICA</a>
							</div>
						<?php endif; ?>
						<?php if($producto->link_mercadolibre != null): ?>
							<div class="col s12 m6" >
								<a href="http://<?php echo e($producto->link_mercadolibre); ?>" target="_blank"  class="waves-effect waves-light btn z-depth-0" id="estandar-btn" style="background: #FFE600;  border-radius: 0 !important"><img src="<?php echo e(asset('images/varios/mercadolibre_btn.png')); ?>" class="resp onsive-img"></a>
							</div>
						<?php endif; ?>
					</div>
				</div>
				<div class="row">
					<div class="col l6 m12 s12" style="font-size: 16px; ">
						<?php echo $producto->caracteristicas; ?>

					</div>
					<div class="col l6 m12 s12">

						<?php if($producto->file_plano != null || $producto->file_plano == ''): ?>
							<div class="col s12 m12 l9">
								<div class="row">
									<p id="productos-show-familia" style="color: #094984 !important;"> Detalles</p>
								</div>
								<img src="<?php echo e(asset('images/productos/plano/'. $producto->file_plano)); ?>"   class="re sponsive-img" alt="">
							</div>
						<?php endif; ?>
					</div>
				</div>
				<div class="row">
					<div class="col l12 m12 s12" style="font-size: 16px;>
						<?php echo $producto->especificaciones; ?>

					</div>
				</div>
				<?php if(count($relacionados) > 0): ?>
					<h5 style="color: #2DC5EE; font-family: quicksand; margin-bottom: 3%">Productos Relacionados</h5>
					<div class="row center">
						<?php $__currentLoopData = $relacionados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<a class="product-item col s12 l4 m6 " style="margin-bottom: 5%" href="<?php echo e(route('show.page', $r->producto_id)); ?>">
							<div class="product-image">
								<img src="<?php echo e(asset('images/productos/'. $r->file_image)); ?>" class="responsive-img">
								<div class="product-overlay">
									<div class="icon">
										<i class="material-icons">add</i>
									</div>
								</div>
							</div>
							<div style="color: #084884;  margin-top: 5%">
								<?php echo e($r->nombre); ?>

							</div>
						</a>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script>
		$(document).ready(function(){
			$('.slider').slider();
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>