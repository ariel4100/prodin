<?php $__env->startSection('style'); ?>
	<style>
		.collapsible {
			border: none;
			box-shadow: none;
		}
		.collapsible-header {
		}
		.collapsible-body {
			padding: 8px;
		}
		a{
			color: #747484;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" >
		<div class="row">
			<div class="breadcrumb-productos" style="padding: 3%">
				<a href="<?php echo e(action('SeccionProductoController@index')); ?>">Productos</a> | <a href="<?php echo e(route('listar.page', $familia->id)); ?>"><?php echo e($familia->nombre); ?></a> | <a href="<?php echo e(route('show.page', $producto->id)); ?>"><?php echo e($producto->nombre); ?></a>
			</div>
			<div class="col s3">
				<ul class="collapsible">
					<?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li <?php if($f->id == $familia->id): ?> class="active"  style="color: #2DC5EE;" <?php endif; ?>>
							<div class="collapsible-header"
								 style="display:flex; justify-content:space-between; align-items:center; padding:8px">
								<a href="<?php echo e(route('listar.page', $f->id)); ?>" <?php if($f->id == $familia->id): ?> style="color: #2DC5EE;" <?php endif; ?> class="graysillo">
									<?php echo e($f->nombre); ?>

								</a>
								<i class="material-icons">keyboard_arrow_right</i>
							</div>
							<div class="collapsible-body" style="padding:0">
								<?php $__currentLoopData = $f->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<ul class="collapsible">
										<li class="active">
											<div class="collapsible-header">
												<a href="" class="graysillo"
												   <?php if(isset($familias)): ?> <?php if($f->id == $p->id): ?> style="color: #2DC5EE;" <?php endif; ?> <?php endif; ?>
												><?php echo e($p->nombre); ?></a>
											</div>
										</li>
									</ul>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<div class="col s9">
				<div class="row">
					<div class="col s6">

						<div class="carousel carousel-slider">
							<a class="carousel-item" href="#one!"><img src="<?php echo e(asset('images/productos/'.$producto->file_image)); ?>"></a>
							<?php if($producto->galerias->count() > 0): ?>
								<?php $__currentLoopData = $producto->galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<a class="carousel-item" href="#one!"><img src="<?php echo e(asset('images/productos/galeria/'.$s->file_image)); ?>"></a>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</div>

					</div>
					<div class="col s6">
						<h5><?php echo e($producto->nombre); ?></h5>
						<p>
							<?php echo $producto->descripcion; ?>

						</p>
						<?php if($producto->file_ficha != null): ?>
							<div class="col s12 m6" >
								<a href="<?php echo e(route('producto-down', $producto->file_ficha)); ?>" target="_blank"  class="waves-effect waves-light btn z-depth-0" id="estandar-btn" style="background: #094984 !important; border-radius: 0 !important">DESCARGAR PDF</a>
							</div>
						<?php endif; ?>
						<?php if($producto->link_mercadolibre != null): ?>
							<div class="col s12 m6" >
								<a href="<?php echo e($producto->link_mercadolibre); ?>" target="_blank"  class="waves-effect waves-light btn z-depth-0" id="estandar-btn" style="background: #FFE600;  border-radius: 0 !important"><img src="<?php echo e(asset('images/varios/mercadolibre_btn.png')); ?>"></a>
							</div>
						<?php endif; ?>
					</div>
				</div>
				<div class="row">
					<div class="col s6">
						<?php echo $producto->caracteristicas; ?>

					</div>
					<div class="col s6">
						<?php if($producto->file_plano != null): ?>
							<div class="col s12 m12 l9">
								<div class="row">
									<p id="productos-show-familia" style="color: "> DETALLES</p>
								</div>
								<img src="<?php echo e(asset('images/productos/plano/'. $producto->file_plano)); ?>" class="" alt="">
							</div>
						<?php endif; ?>
					</div>
				</div>
				<div class="row">
					<div class="col s12">
						<?php echo $producto->especificaciones; ?>

					</div>
				</div>
				<div class="row">
					<div class="col s12">
						<?php $__currentLoopData = $relacionados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="row">
								<div class="col s4 ">
									<a href="<?php echo e(route('show.page', $r->producto->id)); ?>">
										<div class="hover" style="">
											<img src= "<?php echo e(asset('images/productos/'. $r->producto->file_image)); ?>" class="responsive-img"   alt="smaple image">
										</div>
										<p class=" center"><?php echo e($r->producto->nombre); ?></p>
									</a>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>