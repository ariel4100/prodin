<?php $__env->startSection('content'); ?>
<div class="cont ainer">
    <div class="r ow">
        <div class="container container-fluid">
            <div class="row">
                <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col s12" >
                        <?php if($s->id%2 == 0): ?>
                            <div class="col s10  m10 l6" id="descripcion-servicios" style="border-right: 1px solid #BBBBBB; padding-bottom: 10px; text-align: right;">
                                <p class="nombre-servicios" style="text-align: right;"><?php echo e($s->nombre); ?></p>
                                <p class="descripcion_breve-servicios" style="text-align: right;"><?php echo e($s->descripcion_breve); ?></p>
                                <span   class="descripcion-servicios"style="text-align: right;"><?php echo $s->descripcion; ?></span>
                            </div>
                            <div class="col s2  m2 l6" id="image-servicios" style="padding-top: 5%">
                                <img src="<?php echo e(asset('images/servicios/'.$s->file_image)); ?>" class="responsive-img">
                            </div>
                        <?php else: ?>
                            <div class="col s2  m2 l1 offset-l5" id="image-servicios" style="padding-top: 5%">
                                <img src="<?php echo e(asset('images/servicios/'.$s->file_image)); ?>" class="responsive-img">
                            </div>
                            <div class="col s10  m10 l6" id="descripcion-servicios" style="border-left: 1px solid #BBBBBB; padding-bottom: 25px">
                                <p class="nombre-servicios"><?php echo e($s->nombre); ?></p>
                                <p class="descripcion_breve-servicios"><?php echo e($s->descripcion_breve); ?></p>
                                <span class="descripcion-servicios" ><?php echo $s->descripcion; ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>


    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>