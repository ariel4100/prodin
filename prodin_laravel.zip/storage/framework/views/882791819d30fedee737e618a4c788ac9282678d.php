
Has recibido un mensaje de : <?php echo e($nombre); ?>


<p>
Nombre: <?php echo e($nombre); ?>

</p>

<p>
Apellido: <?php echo e($localidad); ?>

</p>

<p>
Email: <?php echo e($email); ?>

</p>




<p>
Empresa: <?php echo e($telefono); ?>

</p>

<p>
Mensaje: <?php echo e($mensaje); ?>

</p>