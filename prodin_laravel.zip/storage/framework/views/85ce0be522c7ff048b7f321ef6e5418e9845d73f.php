<?php $__env->startSection('content'); ?>
<div class="container" id="container-fluid">
    <div class="row">
        <div class="col s12">
            <nav>
                <div class="nav-wrapper grey">
                    <div class="col s12">
                        <a href="<?php echo e(route('home')); ?>" class="breadcrumb">Home</a>
                        <a href="<?php echo e(action('UserController@index')); ?>" class="breadcrumb">Usuarios</a>
                        <a href="#!" class="breadcrumb">Crear</a>
                    </div>
                </div>
            </nav>
            <h5>Crear Usuario</h5>
            <div class="divider" style="margin-bottom: 5%"></div>
            <form method="POST"  enctype="multipart/form-data" action="<?php echo e(action('UserController@store')); ?>" class="col s12 m8 offset-m2 xl10 offset-xl1">
                <?php echo e(csrf_field()); ?>


                <div class="row">
                    <div class="input-field col s6">
                        <i class="material-icons prefix">keyboard_arrow_right</i>
                        <input id="icon_prefix" type="text" class="validate" name="username" required>
                        <label for="icon_prefix">Username</label>
                    </div>
                    <div class="input-field col s6">
                        <i class="material-icons prefix">keyboard_arrow_right</i>
                        <input id="icon_prefix" type="text" class="validate" name="name" >
                        <label for="icon_prefix">Nombre</label>
                    </div>
                    <div class="input-field col s6">
                        <i class="material-icons prefix">keyboard_arrow_right</i>
                        <input id="icon_prefix" type="password" class="validate" name="password" required>
                        <label for="icon_prefix">Contraseña</label>
                    </div>
                    <div class="input-field col s6">
                        <i class="material-icons prefix">keyboard_arrow_right</i>

                        <select name="tipo_usuario" required>
                            <option>::Seleccione Tipo de Usuario::</option>
                            <?php $__currentLoopData = $tipo_usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($index); ?>">  <?php echo e($tipo); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="right">
                        <a href="<?php echo e(action('UserController@index')); ?>"  class="waves-effect waves-light btn">Cancelar</a>
                        <button class="btn waves-effect waves-light" type="submit" name="action">Submit
                            <i class="material-icons right">send</i>
                        </button>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>