<?php $__env->startSection('content'); ?>
<div class="container" id="container-fluid">
    <div class="row">
        <div class="col s12">
            <nav>
                <div class="nav-wrapper grey">
                    <div class="col s12">
                        <a href="<?php echo e(route('home')); ?>" class="breadcrumb">Home</a>
                        <a href="<?php echo e(route('enlace')); ?>" class="breadcrumb">Enlace</a>
                        <a href="#!" class="breadcrumb">Editar</a>
                    </div>
                </div>
            </nav>
            <form method="POST"  enctype="multipart/form-data" action="<?php echo e(action('EnlaceController@update', $enlace->id)); ?>" class="col s12 m8 offset-m2 xl10 offset-xl1">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="row">
                    <h5>Editar Enlace</h5>
                    <div class="divider"></div>
                    <div class="file-field input-field s12">
                        <div class="btn">
                            <span>Imagen</span>
                            <input type="file" name="file_image">

                        </div>
                        <div class="file-path-wrapper">
                            <input class="file-path validate" type="text">
                            <span class="helper-text" data-error="wrong" data-success="right">Tamaño recomendado: 176x28</span>
                        </div>
                    </div>
                    <div class="input-field col s12">
                        <h6>Nombre</h6>
                        <textarea name="nombre" class="validate" id="" cols="30" rows="10"><?php echo $enlace->nombre; ?></textarea>
                    </div>
                    <div class="input-field col s6">
                        <i class="material-icons prefix">text_rotation_none</i>
                        <input id="icon_prefix" type="text" class="validate" name="orden"  value="<?php echo e($enlace->orden); ?>">
                        <label for="icon_prefix">Orden</label>
                    </div>
                </div>

                <div class="row">
                    <div class="right">
                        <a href="<?php echo e(action('EnlaceController@index')); ?>" class="waves-effect waves-light btn btn-color">Cancelar</a>
                        <button class="btn waves-effect waves-light btn-color" type="submit" name="action">Submit
                            <i class="material-icons right">send</i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        CKEDITOR.replace('nombre');

        CKEDITOR.config.height = '150px';

        CKEDITOR.config.width = '100%';



    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>