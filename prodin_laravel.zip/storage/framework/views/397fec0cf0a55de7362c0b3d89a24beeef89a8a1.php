<nav>
    <div class="col s12" >
        <div class="col s3">
            <a href="<?php echo e(url('/')); ?>" class="brand-logo">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="">
            </a>
        </div>
        <div class="col s9 right" style="    margin: 10px 85px 0px 0px;">
            <ul class="hide-on-med-and-down" style="display: flex; justify-content: right; align-items: center; height: 5px;">
                <a href="https://wa.me/541565280542" target="_blank"> <i class="fab fa-whatsapp fs14" style="font-size: 20px; color: #25d366; line-height: unset; padding-right: 5px"></i>15 6528 - 0542 </a>
                <a href="tel:+54 11 2062-1307"><i class="material-icons" style="font-size: 20px; float: left; color: #2DC5EE; line-height: unset; padding-right: 5px" >phone_in_talk</i>011 2062 - 1307</a>
                <a href="mailto:prodin@prodinautamocion.com.ar"><i class="material-icons" style="font-size: 20px; float: left;  line-height: unset; padding-right: 5px; color: #2DC5EE;">mail_outline</i>prodin@prodinautomacion.com.ar</a>
            </ul>
        </div>
        <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
        <div class="col s9" id="seccion-active" style="width: 95%; font-family: quicksand" >
            <ul class="right hide-on-med-and-down " style="    margin: 10px;">
                <li><a href="<?php echo e(route('empresa.page')); ?>" class="<?php echo e(request()->is('empresa') ? 'activea' : ''); ?>" >EMPRESA</a></li>
                <li><a href="<?php echo e(route('productos.page')); ?>" class="<?php echo e(request()->is('productos') ? 'activea' : ''); ?>" >PRODUCTOS</a></li>
                <li><a href="<?php echo e(route('servicios.page')); ?>" class="<?php echo e(request()->is('servicios') ? 'activea' : ''); ?>" >SERVICIOS</a></li>
                <li><a href="<?php echo e(route('presupuesto.page')); ?>" class="<?php echo e(request()->is('presupuesto') ? 'activea' : ''); ?>" >SOLICITUD DE PRESUPUESTO</a></li>
                <li><a href="<?php echo e(route('contacto.index')); ?>" class="<?php echo e(request()->is('contacto') ? 'activea' : ''); ?>" >CONTACTO</a></li>
                <li>
                    <a href="<?php echo e(url('/')); ?>" class="btn-floating btn-large waves-effect waves-light" style="background-color: #2DC5EE;width: 35px;height: 35px;">
                        <i style="line-height:37px;" class="material-icons">search</i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<ul class="sidenav" id="mobile-demo">
    <li><a href="<?php echo e(route('empresa.page')); ?>" class="<?php echo e(request()->is('empresa') ? 'activea' : ''); ?>" >EMPRESA</a></li>
    <li><a href="<?php echo e(route('productos.page')); ?>" class="<?php echo e(request()->is('productos') ? 'activea' : ''); ?>" >PRODUCTOS</a></li>
    <li><a href="<?php echo e(route('servicios.page')); ?>" class="<?php echo e(request()->is('servicios') ? 'activea' : ''); ?>" >SERVICIOS</a></li>
    <li><a href="<?php echo e(route('presupuesto.page')); ?>" class="<?php echo e(request()->is('presupuesto') ? 'activea' : ''); ?>" >SOLICITUD DE PRESUPUESTO</a></li>
    <li><a href="<?php echo e(route('contacto.index')); ?>" class="<?php echo e(request()->is('contacto') ? 'activea' : ''); ?>" >CONTACTO</a></li>
</ul>
