<?php $__env->startSection('content'); ?>
	<div class="container" id="container-fluid">
		<div class="row">
			<div class="col s12">
				<?php echo $__env->make('adm.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<nav>
					<div class="nav-wrapper grey">
						<div class="col s12">
							<a href="<?php echo e(route('home')); ?>" class="breadcrumb">Home</a>
							<a href="#!" class="breadcrumb">Condiciones</a>
						</div>
					</div>
				</nav>

				<div class="divider"></div>

				<form method="POST"  enctype="multipart/form-data" action="<?php echo e(action('CondicionController@update', $condicion->id)); ?>" class="col s12 m8 offset-m2 xl10 offset-xl1">
					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('PUT')); ?>


					<div class="row">

						<div class="row">

							<div class="col s12">
								<h5>Terminos y Condiciones</h5>
							</div>
							<div class="input-field col s12">
								<textarea id="descripcion" name="descripcion"> <?php echo e($condicion->descripcion); ?> </textarea>
							</div>

						</div>
						<div class="right">
							<button class="btn waves-effect waves-light btn-color" type="submit" name="action">Submit
								<i class="material-icons right">send</i>
							</button>
						</div>
					</div>
				</form>

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script>
		CKEDITOR.replace('descripcion');

		CKEDITOR.config.height = '150px';

		CKEDITOR.config.width = '100%';


	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>