<?php $__env->startSection('content'); ?>
<div class="container" id="container-fluid">
    <div class="row">
        <div class="col s12">
            <h5>Logos</h5>
            <div class="divider"></div>
            <table class="index-table-logos responsive-table ">
                <thead>
                <tr>
                    <th>Logo</th>
                    <th>Ubicación</th>
                    <th>Opciones</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $logos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="width: 350px"><img src="<?php echo e(asset('images/logos/'.$l->file_image)); ?>"></td>
                        <?php switch($l->ubicacion):
                            case ('navbar'): ?>
                            <td>Barra Principal</td>
                            <?php break; ?>
                            <?php case ('footer'): ?>
                            <td>Pie de Página</td>
                            <?php break; ?>
                            <?php default: ?>
                            <td>Favicon</td>
                        <?php endswitch; ?>
                        <td>
                            <a href=" <?php echo e(action('LogosController@edit', $l->id)); ?> " class="btn-floating btn-large waves-effect waves-light orange"><i class="fas fa-pencil-alt"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3">No existen registros</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>