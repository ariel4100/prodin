<?php $__env->startSection('content'); ?>
<div class="container" id="container-fluid">
    <div class="row">
        <div class="col s12">
        <h5>Galeria de Imágenes | Producto: <?php echo $producto->nombre; ?></h5>
            <div class="row">
                <div class="right">
                    <a href=" <?php echo e(action('GaleriaController@create', $producto->id)); ?> " class="btn waves-effect waves-light orange"><i style="font-size: 15px" class="fas fa-plus-circle"></i>AGREGAR</a>
                </div>
            </div>

            <div class="divider"></div>

            <div class="col s12" style="margin-top: 5%">
                <table class="index-table responsive-table ">
                    <thead>
                    <tr>
                        <th>Imagen</th>
                        <th>Opciones</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $producto->galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>
                            <td style="width: 350px"><img src=" <?php echo e(asset('images/productos/galeria/'.$g->file_image)); ?> " alt=""></td>
                            <td>
                                <a href=" <?php echo e(action('GaleriaController@edit', $g->id)); ?> " class="btn-floating btn waves-effect waves-light orange"><i style="font-size: 15px" class="fas fa-pencil-alt"></i></a>
                                <a onclick="return confirm('¿Realmente desea eliminar este registro?')"  href="<?php echo e(action('GaleriaController@eliminar', $g->id)); ?>" class="btn-floating btn waves-effect waves-light teal"><i class="material-icons">delete</i></a>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            <td colspan="3">No se consiguieron registros</td>
                        </tr>

                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="row">
                <div class="right" style="padding: 2%">
                    <a href="<?php echo e(action('ProductoController@index', $producto->id)); ?>" class="waves-effect waves-light btn">Volver</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>