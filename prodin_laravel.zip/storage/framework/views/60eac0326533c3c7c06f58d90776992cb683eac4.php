<?php if($errors->any()): ?>
	<div class="card-panel alert-error" style="background-color: red; color: white">
		<ul><li>ALERTA:
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($error); ?>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</li>
		</ul>
	</div>
<?php endif; ?>

<?php if(session('alert')): ?>
	<div class="card-panel alert-success">
		<ul><li>ALERTA:
				<?php echo e(session('alert')); ?>

			</li>
		</ul>
	</div>
<?php endif; ?>