<?php $__env->startSection('style'); ?>
	<style>
		.collapsible {
			border: none;
			box-shadow: none;
		}
		.collapsible-header {
		}
		.collapsible-body {
			padding: 8px;
		}
		a{
			color: #747484;
		}

		.hover {
			background-color: rgba(0,0,0,0.7);


		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" style=" ">
		<div class="row">
			<div class="breadcrumb-productos" style="padding: 3%">
				<a href="<?php echo e(action('SeccionProductoController@index')); ?>">Productos</a> | <a href="<?php echo e(route('listar.page', $familia->id)); ?>"><?php echo e($familia->nombre); ?></a>
			</div>
			<div class="col s3">
				<ul class="collapsible">
					<?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li <?php if($f->id == $familia->id): ?>  style="color: #2DC5EE;" <?php endif; ?>>
							<div class="collapsible-header"
								 style="display:flex; justify-content:space-between; align-items:center; padding:8px">
								<a href="<?php echo e(route('listar.page', $f->id)); ?>" <?php if($f->id == $familia->id): ?> style="color: #2DC5EE;" <?php endif; ?>  class="gra ysillo">
									<?php echo e($f->nombre); ?>

								</a>
								<i class="material-icons">keyboard_arrow_right</i>
							</div>
							<div class="collapsible-body" style="padding:0">
								<?php $__currentLoopData = $f->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<ul class="collapsible">
										<li class="active">
											<div class="collapsible-header">
												<a href="<?php echo e(route('show.page', $p->id)); ?>" class="graysillo"

												><?php echo e($p->nombre); ?></a>
											</div>
										</li>
									</ul>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<div class="col s9">
				<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="row">
						<div class="col s4 ">
							<a href="<?php echo e(route('show.page', $p->id)); ?>">
								<div class="" style="">
									<img src= "<?php echo e(asset('images/productos/'. $p->file_image)); ?>" class="responsive-img"   alt="smaple image">
								</div>
								<p class=" center"><?php echo e($p->nombre); ?></p>
							</a>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>