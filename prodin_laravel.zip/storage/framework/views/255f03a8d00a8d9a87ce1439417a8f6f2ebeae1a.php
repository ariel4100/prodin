<?php $__env->startSection('content'); ?>
<div class="container" id="container-fluid">
    <div class="row">
        <div class="col s12">
            <h5>Sliders Home</h5>
            <div class="divider"></div>
            <table class="index-table responsive-table ">
                <thead>
                <tr>
                    <th>Imagen</th>
                    <th>Título</th>
                    <th>Orden</th>
                    <th>Opciones</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>
                        <td style="width: 350px"><img src="<?php echo e(asset('images/sliders/'.$s->file_image)); ?>"></td>
                        <td><?php echo $s->titulo; ?></td>
                        <td><?php echo e($s->orden); ?></td>
                        <td>
                            <a href=" <?php echo e(action('SliderController@edit', ['id' => $s->id, 'seccion' => $seccion])); ?> " class="btn-floating btn-large waves-effect waves-light orange"><i class="fas fa-pencil-alt"></i></a>
                            <a onclick="return confirm('¿Realmente desea eliminar este registro?')"  href=" <?php echo e(action('SliderController@eliminar', ['id' => $s->id])); ?> " class="btn-floating btn-large waves-effect waves-light deep-orange"><i class="fas fa-trash-alt"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">No existen registros</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>