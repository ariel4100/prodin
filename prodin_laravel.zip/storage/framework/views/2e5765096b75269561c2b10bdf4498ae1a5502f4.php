<?php $__env->startSection('style'); ?>
	<style>

		.efecto{
			position: absolute;
			opacity: 0;
			background-color: transparent;
			height: 100%;
			z-index: 6;
			mix-blend-mode: multiply;
		}

		.efecto:hover{
			opacity: 1;
			transition: 1s;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container container-fluid" style="padding-top: 5%">
		<div class="row">

			<?php $__empty_1 = true; $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="col s12 m12 l4 center" >
					<div class="subfamilia-productos center">
						<div class=" ">
							<a href="<?php echo e(action('SeccionProductoController@show', ['id' => $s->id])); ?>">
								<img class="subfamilia-img" src="<?php echo e(asset('images/productos/'.$s->file_image)); ?>">
							</a>
						</div>

					</div>
					<p style="font-size: 14px;"> <?php echo e($s->nombre); ?> </p>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<p>
					No conseguimos productos relacionados a esta categoría
				</p>
			<?php endif; ?>
		</div>
	</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>