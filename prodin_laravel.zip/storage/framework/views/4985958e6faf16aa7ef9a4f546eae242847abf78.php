<?php $__env->startSection('content'); ?>
<div class="container" id="container-fluid">
    <div class="row">
        <div class="col s12">
            <nav>
                <div class="nav-wrapper grey">
                    <div class="col s12">
                        <a href="<?php echo e(route('home')); ?>" class="breadcrumb">Home</a>
                        <a href="<?php echo e(route('categorias.index')); ?>" class="breadcrumb">Familia</a>
                    </div>
                </div>
            </nav>
            <h5>Familias</h5>
            <div class="divider"></div>
            <table class="index-table-logos responsive-table ">
                <thead>
                <tr>
                    <th>Imagen</th>
                    <th>Nombre</th>
                    <th>Orden</th>
                    <th>Opciones</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="width: 350px;"><img src="<?php echo e(asset('images/categoria/'.$f->file_image)); ?>"></td>
                        <td ><?php echo e($f->nombre); ?></td>
                        <td><?php echo e($f->orden); ?></td>
                        <td>
                            <a href=" <?php echo e(route('categorias.edit', $f->id)); ?> " class="btn-floating btn-large waves-effect waves-light orange"><i class="fas fa-pencil-alt"></i></a>
                            <form action="<?php echo e(route('categorias.destroy', $f->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button onclick="return confirm('¿Realmente desea eliminar este registro?')" type="submit" class="btn-floating btn-large waves-effect waves-light red">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">No existen registros</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>