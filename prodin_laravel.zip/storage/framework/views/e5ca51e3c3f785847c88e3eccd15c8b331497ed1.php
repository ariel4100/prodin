<?php $__env->startSection('content'); ?>
    <div class="carousel carousel-slider center">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item   white-text" href="#one!" style="background-image: url(<?php echo e(asset('images/sliders/'.$s->file_image)); ?>); align-items: center">
               <div class="row">
                   <div class="col s4 offset-s4" style="pad ding: -20px 20px -20px 20px; background-color: #2DC5EE;">
                       <h2 class="center-align">CILINDROS NEUMATICOS E HIDRAULICOS</h2>
                   </div>
               </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<div class="container" style="margin-top: 4rem">
    <div class="row">
        <div class="col l6 s12">
            <h5  ><?php echo e($empresa->titulo1); ?></h5>
            <p class="">
                <?php echo $empresa->descripcion; ?>

            </p>
        </div>
        <div class="col l6 s12">
            <img src="<?php echo e(asset('images/empresa/'.$empresa->file_image)); ?>" alt="img" class="responsive-img">
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>