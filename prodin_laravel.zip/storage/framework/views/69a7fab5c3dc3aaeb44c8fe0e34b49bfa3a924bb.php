<?php $__env->startSection('content'); ?>
<div class="container" id="container-fluid">
    <div class="row">
        <div class="col s12">
            <h5>Seleccionar Productos Destacados</h5>
            <div class="divider"></div>
            <form method="POST"  enctype="multipart/form-data" action="<?php echo e(action('ProductoDestacadoController@store')); ?>" class="col s12 m8 offset-m2 xl10 offset-xl1">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('POST')); ?>


                <div class="row">
                    <div class="divider"></div>
                    <div class="input-field col s10">
                        <select name="producto_id">
                            <?php $__currentLoopData = $destacados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->id); ?>" data-icon="<?php echo e(asset('images/productos/'.$d->file_image)); ?>" class="left"><?php echo e(ucwords($d->nombre)); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="input-field col s2">
                        <i class="material-icons prefix">keyboard_arrow_right</i>
                        <input id="icon_prefix" type="text" class="validate" name="orden">
                        <label for="icon_prefix">Orden</label>
                    </div>
                </div>
                <div class="row">
                    <div class="right">
                        <a href="<?php echo e(action('ProductoDestacadoController@index')); ?>" class="waves-effect waves-light btn btn-color">Cancelar</a>
                        <button class="btn waves-effect waves-light btn-color" type="submit" name="action">Submit
                            <i class="material-icons right">send</i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>