
Has recibido un mensaje de : <?php echo e($nombre); ?>


<p>
Nombre: <?php echo e($nombre); ?>

</p>

<p>
Apellido: <?php echo e($apellido); ?>

</p>

<p>
Email: <?php echo e($email); ?>

</p>




<p>
Empresa: <?php echo e($empresa); ?>

</p>

<p>
Mensaje: <?php echo e($mensaje); ?>

</p>