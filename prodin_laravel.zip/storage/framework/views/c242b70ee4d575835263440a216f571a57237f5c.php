<?php $__env->startSection('content'); ?>
<div class="container" id="container-fluid">
    <div class="row">
        <div class="col s12">
            <nav>
                <div class="nav-wrapper grey">
                    <div class="col s12">
                        <a href="<?php echo e(route('home')); ?>" class="breadcrumb">Home</a>
                        <a href="<?php echo e(route('productos.index')); ?>" class="breadcrumb">Productos</a>
                    </div>
                </div>
            </nav>
            <h5>Productos</h5>
            <div class="divider"></div>
            <table class="index-table-logos responsive-table ">
                <thead>
                <tr>
                    <th>Imagen</th>
                    <th>Nombre</th>
                    <th>Familia</th>
                    <th>Orden</th>
                    <th>Opciones</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="width: 150px;"><img src="<?php echo e(asset('images/productos/'.$p->file_image)); ?>"></td>
                        <td ><?php echo e($p->nombre); ?></td>
                        <td>
                            <?php if($p->categoria): ?>
                                <?php echo e($p->categoria->nombre); ?>

                            <?php else: ?>
                                no tiene categoria
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($p->orden); ?></td>
                        <td>
                            <a href="<?php echo e(action('ProductoController@edit', $p->id)); ?>" class="btn-floating btn waves-effect waves-light orange"><i style="font-size: 15px" class="fas fa-pencil-alt"></i></a>
                            <a href="<?php echo e(action('GaleriaController@index', $p->id)); ?>" class="btn-floating btn waves-effect waves-light pink"><i style="font-size: 15px" class="fas fa-images"></i></a>
                            <form action="<?php echo e(route('productos.destroy', $p->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button onclick="return confirm('¿Realmente desea eliminar este registro?')" type="submit" class="btn-floating btn  waves-effect waves-light red">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">No existen registros</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>