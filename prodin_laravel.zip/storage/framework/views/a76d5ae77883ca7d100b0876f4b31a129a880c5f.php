<?php $__env->startSection('content'); ?>


<div class="container" style="margin-top: 4rem">
    <div class="row" >
        <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('listar.page', $f->id)); ?>">
                <div class="col s3">
                    <div class="">
                        <img src= "<?php echo e(asset('images/categoria/'. $f->file_image)); ?>" class="responsive-img"   alt="smaple image">
                    </div>
                    <p class=" center"><?php echo e($f->nombre); ?></p>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>